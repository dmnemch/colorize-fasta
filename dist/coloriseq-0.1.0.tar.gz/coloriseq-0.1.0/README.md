# colorize-fasta
Colorize fasta files with given patterns and annotate polyA/polyT
